import Data.Char

main::IO()

code = ord '='
main = putStrLn ("The character code of '=' is " ++ (show code))
