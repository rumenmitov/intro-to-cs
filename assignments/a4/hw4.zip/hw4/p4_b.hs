import Data.Char

main::IO()

main = putStrLn ("The character is " ++ [ chr 12811 ])
